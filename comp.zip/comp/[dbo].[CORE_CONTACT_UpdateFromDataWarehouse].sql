USE [RackspaceHybridControl]
GO

/****** Object:  StoredProcedure [dbo].[CORE_CONTACT_UpdateFromDataWarehouse]    Script Date: 2020-02-26 23:11:16 ******/
DROP PROCEDURE [dbo].[CORE_CONTACT_UpdateFromDataWarehouse]
GO

/****** Object:  StoredProcedure [dbo].[CORE_CONTACT_UpdateFromDataWarehouse]    Script Date: 2020-02-26 23:11:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/****** Object:  StoredProcedure [dbo].[CORE_CONTACT_UpdateFromDataWarehouse]    Script Date: 2020-02-17 1:06:37 PM ******/
CREATE PROCEDURE [dbo].[CORE_CONTACT_UpdateFromDataWarehouse]
AS
	DELETE FROM		CORE_CONTACT_STAGE

	INSERT INTO		CORE_CONTACT_STAGE
					(
						core_account_id,
						core_contact_id
					)
					SELECT DISTINCT ac.account_number AS core_account_number, ac.contact_core_contact_id AS core_contact_id
						FROM [ebi-datamart].[corporate_dmart].dbo.dim_account a
						JOIN [ebi-datamart].[corporate_dmart].dbo.vw_account_contact ac
						ON a.account_key = ac.account_key
						WHERE ac.account_number IN
							(
								SELECT		CAST(da.core_account_number as varchar(50))
								FROM		DEDICATED_ACCOUNT da
								LEFT JOIN	CORE_ACCOUNT ca
								ON			da.core_account_number = ca.core_account_id
								WHERE		ISNULL(da.active_end_utc, '2099-12-31') > GETUTCDATE()
								AND			ca.core_account_id IS NOT NULL
							)
						AND a.current_record = 1
						AND ac.contact_type = 'EXTERNAL'
						AND ac.contact_role_name IN ('Primary Contact', 'Reviewer', 'Technical')
						AND (ac.contact_core_contact_id IS NOT NULL AND ac.contact_core_contact_id <>'unknown' AND ac.contact_core_contact_id <>'0')

	IF EXISTS		(SELECT * FROM CORE_CONTACT_STAGE)
	BEGIN
		BEGIN TRANSACTION

		DELETE FROM		CORE_CONTACT
		
		INSERT INTO		CORE_CONTACT
						(
							core_account_id,
							core_contact_id
						)
							SELECT		ccs.core_account_id, ccs.core_contact_id
							FROM		CORE_CONTACT_STAGE ccs
							WHERE		core_account_id NOT IN (SELECT		DISTINCT ccir.core_account_id 
																FROM		CORE_CONTACT_IMPORT_RESTRICTION ccir 
																INNER JOIN	CORE_CONTACT_STAGE ccs1
																ON			ccs1.core_contact_id = ccir.core_contact_id
																WHERE		ISNULL(ccir.active_end_utc, '2099-12-31') > GETUTCDATE())
						UNION
							SELECT		ccir.core_account_id, ccir.core_contact_id
							FROM		CORE_CONTACT_IMPORT_RESTRICTION ccir 
							INNER JOIN	CORE_CONTACT_STAGE ccs
							ON			ccs.core_contact_id = ccir.core_contact_id
							WHERE		ISNULL(ccir.active_end_utc, '2099-12-31') > GETUTCDATE()
		
		SELECT			'Update successful'
		
		COMMIT TRANSACTION
	END
	ELSE
	BEGIN
		SELECT			'Update failed'
	END
	


GO


